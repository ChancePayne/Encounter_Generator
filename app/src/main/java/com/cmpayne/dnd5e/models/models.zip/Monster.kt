package com.cmpayne.dnd5e.models

import Action
import Hp
import OtherSources
import Skill
import Speed
import SubAction
import Trait
import Type
import com.google.gson.Gson
import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import com.google.gson.annotations.SerializedName

/*
Copyright (c) 2020 Kotlin Data Classes Generated from JSON powered by http://www.json2kotlin.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar */


data class Monster(

    @SerializedName("name") val name: String,
    @SerializedName("size") val size: String,
    @SerializedName("source") val source: String,
    @SerializedName("alignment") val alignment: List<String>,
	@SerializedName("ac") val armorClass : List<Int>,
    @SerializedName("hp") val hp: Hp,
    @SerializedName("speed") val speed: Speed,
    @SerializedName("str") val str: Int,
    @SerializedName("dex") val dex: Int,
    @SerializedName("con") val con: Int,
    @SerializedName("int") val int: Int,
    @SerializedName("wis") val wis: Int,
    @SerializedName("cha") val cha: Int,
    @SerializedName("skill") val skill: Skill,
    @SerializedName("passive") val passive: Int,
    @SerializedName("languages") val languages: List<String>,
    @SerializedName("cr") val challenge: String,
    @SerializedName("trait") val trait: List<Trait>,
    @SerializedName("page") val page: Int,
    @SerializedName("environment") val environment: List<String>,
    @SerializedName("soundClip") val soundClip: String,
    @SerializedName("languageTags") val languageTags: List<String>,
    @SerializedName("damageTags") val damageTags: List<String>,
    @SerializedName("miscTags") val miscTags: List<String>,
    @SerializedName("otherSources") val otherSources: List<OtherSources>
) {
    /*@SerializedName("typeObj")*/ lateinit var typeObj: Type
    /*@SerializedName("action")*/ lateinit var actionList: MutableList<Action>
}

class MonsterDeserializer : JsonDeserializer<Monster> {
    override fun deserialize(
        json: JsonElement,
        typeOfT: java.lang.reflect.Type,
        context: JsonDeserializationContext
    ): Monster {
        val gson = Gson()
        val monster = gson.fromJson(json, Monster::class.java)
        val jsonObject = json.getAsJsonObject()

        // custom type
        val typeFieldName = "type"
        if (jsonObject.has(typeFieldName)) {
            val element = jsonObject.get(typeFieldName)
            if (element != null && !element.isJsonNull()) {
                monster.typeObj = if (element.isJsonObject) {

                    val tagElements = element.asJsonObject.get("tags").asJsonArray.toList()
                    val tags = MutableList(tagElements.size) { "" }
                    tagElements.forEachIndexed { index, jsonElement ->
                        tags[index] = jsonElement.asString
                    }

                    Type(element.asJsonObject.get(typeFieldName).asString, tags)
                } else {
                    Type(element.asString, emptyList())
                }
            }
        }

        //custom action
        monster.actionList = mutableListOf()
        val actionFieldName = "action"
        if (jsonObject.has(actionFieldName)) {
            jsonObject.get(actionFieldName).asJsonArray.forEachIndexed { index, element ->
                if (element != null && !element.isJsonNull()) {
                    val action =
                        Action(element.asJsonObject.get("name").asString, mutableListOf<String>())
                    val entryJson = element.asJsonObject.get("entries").asJsonArray
                    entryJson.forEachIndexed { entryIndex, entryElement ->
                        if (!entryElement.isJsonObject) {
                            action.entries.add(entryElement.asString)
                        } else {
                            val items = entryElement.asJsonObject.get("items").asJsonArray
                            if (items != null && !items.isJsonNull()) {
                                items.forEach {
                                    action.subActions.add(
                                        SubAction(
                                            it.asJsonObject.get("name").asString,
                                            it.asJsonObject.get("entry").asString
                                        )
                                    )
                                }
                            }
                        }
                    }
                    monster.actionList.add(action)
                }
            }
        }

        //custom speed


        return monster
    }

}
