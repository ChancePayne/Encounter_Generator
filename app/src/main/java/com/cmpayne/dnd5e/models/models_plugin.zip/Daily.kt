package com.cmpayne.dnd5e.models

data class Daily(
    val `3e`: List<String>
)