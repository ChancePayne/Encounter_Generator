package com.cmpayne.dnd5e.models

data class Variant(
    val entries: List<String>,
    val name: String,
    val type: String
)