package com.cmpayne.dnd5e.models

data class Save(
    val wis: String
)