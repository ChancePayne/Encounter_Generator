package com.cmpayne.dnd5e.models

import com.google.gson.annotations.SerializedName

data class Monsters(
    @SerializedName("monster") val monsters: List<Monster>
)