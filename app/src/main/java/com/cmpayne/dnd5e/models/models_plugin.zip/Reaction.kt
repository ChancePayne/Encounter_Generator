package com.cmpayne.dnd5e.models

data class Reaction(
    val entries: List<String>,
    val name: String
)