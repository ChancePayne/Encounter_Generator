package com.cmpayne.dnd5e.models

data class LegendaryGroup(
    val name: String,
    val source: String
)