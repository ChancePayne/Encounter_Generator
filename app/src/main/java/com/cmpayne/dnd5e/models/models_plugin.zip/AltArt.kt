package com.cmpayne.dnd5e.models

data class AltArt(
    val name: String,
    val source: String
)