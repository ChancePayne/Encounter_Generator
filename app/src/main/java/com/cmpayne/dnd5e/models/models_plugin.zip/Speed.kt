package com.cmpayne.dnd5e.models

data class Speed(
    val walk: Int
)