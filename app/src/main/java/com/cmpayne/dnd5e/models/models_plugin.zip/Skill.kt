package com.cmpayne.dnd5e.models

data class Skill(
    val deception: String,
    val perception: String,
    val stealth: String
)