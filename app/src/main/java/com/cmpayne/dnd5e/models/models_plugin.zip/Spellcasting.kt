package com.cmpayne.dnd5e.models

data class Spellcasting(
    val ability: String,
    val daily: Daily,
    val headerEntries: List<String>,
    val name: String,
    val will: List<String>
)