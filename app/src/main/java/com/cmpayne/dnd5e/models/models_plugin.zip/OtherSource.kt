package com.cmpayne.dnd5e.models

data class OtherSource(
    val source: String
)