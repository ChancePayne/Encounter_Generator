package com.cmpayne.dnd5e.models

data class Action(
    val entries: List<String>,
    val name: String
)