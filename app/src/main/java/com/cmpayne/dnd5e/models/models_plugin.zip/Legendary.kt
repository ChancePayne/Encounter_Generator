package com.cmpayne.dnd5e.models

data class Legendary(
    val entries: List<String>,
    val name: String
)