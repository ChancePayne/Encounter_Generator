package com.cmpayne.dnd5e.models

data class Trait(
    val entries: List<String>,
    val name: String
)