package com.cmpayne.dnd5e.models

data class Hp(
    val average: Int,
    val formula: String
)